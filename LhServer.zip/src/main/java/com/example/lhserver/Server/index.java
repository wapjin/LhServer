package com.example.lhserver.Server;
import com.example.lhserver.tools.XmlJq;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class index {

    @CrossOrigin(origins = "*")
    @GetMapping("/GetOrderMsg")
    public String test(String pay){
        XmlJq p = new XmlJq();
//        String a = ;
        ArrayList arr = p.getXmlJq(pay);
//        System.out.println(arr.get(0));
//        System.out.print(arr.get(1));
        JSONObject object = new JSONObject();
        //string
        try {
            object.put("message",arr.get(0));
            object.put("signature",arr.get(1));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return object.toString();
    }

    @CrossOrigin(origins = "*")
    @GetMapping ("/")
    public String login(String  pwd,String username){
        System.out.println("pwd:"+pwd+"username:"+username);
        return  "server";
    }
}

