package com.example.lhserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LhServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LhServerApplication.class, args);
    }

}
