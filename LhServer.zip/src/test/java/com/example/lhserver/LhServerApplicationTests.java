package com.example.lhserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LhServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
